export const environments = [
  {
    id: 'neutral', // THREE.RoomEnvironment
    name: 'Neutral',
    path: null,
    index: 0,
  },
  {
    id: 'venice-sunset',
    name: 'Venice Sunset',
    path: 'Environments/venice_sunset_1k.exr',
    format: '.exr',
    index: 1,
  },
  {
    id: 'footprint-court',
    name: 'Footprint Court (HDR Labs)',
    path: 'Environments/footprint_court_2k.exr',
    format: '.exr',
    index: 2,
  },
  {
    id: '',
    name: 'Select Color',
    index: 3,
  }
];