import React from 'react';

function Dashboard() {
  return (
    <div>
      <p>Welcome to the Dashboard!</p>
    </div>
  );
}

export default Dashboard;
